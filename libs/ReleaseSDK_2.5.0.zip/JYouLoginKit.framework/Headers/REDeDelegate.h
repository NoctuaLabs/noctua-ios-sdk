
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,USERCENTER_TYPE){
    USERCENTER_TYPE_Guest = 0,        //guest
    USERCENTER_TYPE_EMAIl = 1,        //email
};

@protocol REDeInitCallback <NSObject>
//初始化完成
- (void)qgSDKInitDone;
@end
@protocol REDeLoginCallback <NSObject>
//绑定回调
- (void)bindUid:(NSString *)uid userToken:(NSString *)token type:(USERCENTER_TYPE)type;
//解绑回调
- (void)unBindUid:(NSString *)uid userToken:(NSString *)token type:(USERCENTER_TYPE)type;
//在SDK的个人中心主动退出登录
- (void)userLogout;
@optional
/** logout执行完毕回调 */
- (void)gameLogoutComplete;
/** 用户取消登录 */
- (void)userCancelLogin;
/* 登录成功与带登录方式实现其一即可 */
- (void)loginUid:(NSString *)uid userToken:(NSString *)token;
/* 登录成功带登录方式与不带登录方式实现其一即可 */
- (void)loginUid:(NSString *)uid userToken:(NSString *)token type:(USERCENTER_TYPE)type;
@end
@protocol REDeBuyCallback <NSObject>
//这里的成功不能作为发货依据
//购买完成 内购商品Id SDK订单号
- (void)purchaseDoneProductId:(NSString *)productId orderNo:(NSString *)orderNo;
//购买失败
- (void)purchaseFail;
@end

@protocol REDeRestoreCallback <NSObject>
//恢复非消耗商品成功，返回商品id信息
- (void)restoreSuccess:(NSArray *)products;
//恢复失败
- (void)restoreFail:(NSString *)msg;

@end
@protocol REProductInfoCallback <NSObject>
//查找商品信息成功数组元素为REDeOrderInfo实例
- (void)findProductInfoSuccess:(NSArray *)products;
//查找商品信息失败
- (void)findProductInfoFail:(NSString *)msg;

@end
